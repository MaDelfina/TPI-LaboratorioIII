export const USERS = [
    {id: 1, username: "Nicolas", password: "Nicolas123", rol: "super-admin"}, 
    {id: 2, username: "Anabella", password: "Anabella123", rol: "super-admin"}, 
    {id: 3, username: "Delfina", password: "Delfina123", rol: "super-admin"},
    {id: 4, username: "pepe", password: "pepe123", shopping_cart: [], rol: "client"},
    {id: 5, username: "marta", password: "marta123", rol: "admin"}
]

export const PIZZAS = [
    {
        id: 1,
        name: "Neapolitan",
        description: "Delicious pizza with tomato sauce, mozzarella, and anchovies.",
        price: 10,
        stock: 0,
        imageUrl:'https://i.postimg.cc/DwcbBxMf/pizza-Gato.jpg'
        // imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },
    {
        id: 2,
        name: "Margherita",
        description: "Classic pizza with tomato sauce, mozzarella, and fresh basil.",
        price: 8,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },
    {
        id: 3,
        name: "Pepperoni",
        description: "Pizza with tomato sauce, mozzarella, and spicy pepperoni.",
        price: 12,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },
    {
        id: 4,
        name: "Hawaiian",
        description: "Tropical pizza with tomato sauce, mozzarella, ham, and pineapple.",
        price: 11,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },
    {
        id: 5,
        name: "Four Cheese",
        description: "Pizza with a variety of cheeses such as mozzarella, cheddar, parmesan, and gorgonzola.",
        price: 13,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },
    {
        id: 6,
        name: "Vegetarian",
        description: "Vegetarian with tomato sauce, mozzarella, mushrooms, peppers, and onions.",
        price: 9,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },
    {
        id: 7,
        name: "Barbecue",
        description: "Pizza with barbecue sauce, mozzarella, shredded chicken, onions, and corn.",
        price: 14,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },
    {
        id: 8,
        name: "Seafood",
        description: "Pizza with tomato sauce, mozzarella, mussels, clams, and shrimp.",
        price: 15,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },    
    {
        id: 9,
        name: "Four Cheese",
        description: "Pizza with a variety of cheeses such as mozzarella, cheddar, parmesan, and gorgonzola.",
        price: 13,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },
    {
        id: 10,
        name: "Vegetarian",
        description: "Vegetarian with tomato sauce, mozzarella, mushrooms, peppers, and onions.",
        price: 9,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },
    {
        id: 11,
        name: "Barbecue",
        description: "Pizza with barbecue sauce, mozzarella, shredded chicken, onions, and corn.",
        price: 14,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    },
    {
        id: 12,
        name: "Seafood",
        description: "Pizza with tomato sauce, mozzarella, mussels, clams, and shrimp.",
        price: 15,
        stock: 0,
        imageUrl: "https://i.postimg.cc/mkkxk6h5/ivan-torres-MQUqbmsz-GGM-unsplash.jpg"
    }
]